"""
URL configuration for tectoken_project project.
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # Panel de Admin de Django
    path('admin/', admin.site.urls),
    
    # URLs de Login, Logout, Cambio de Contraseña, etc.
    # (Ej: /accounts/login/)
    path('accounts/', include('django.contrib.auth.urls')),
    
    # URLs de nuestra app 'tokens' (Home, Tienda, Paneles)
    # Esto le dice a Django: "Para cualquier URL que no sea admin/ o accounts/,
    # ve a buscar en el archivo 'tokens.urls' qué hacer."
    path('', include('tokens.urls')),
]