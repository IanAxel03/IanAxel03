from django import forms
from django.contrib.auth.models import User
from .models import Grupo, Producto

# Formulario para crear un nuevo usuario (Alumno o Profesor)
class UserCreationForm(forms.ModelForm):
    # Campos adicionales para contraseña
    password = forms.CharField(widget=forms.PasswordInput, required=True, label="Contraseña")
    password_confirm = forms.CharField(widget=forms.PasswordInput, required=True, label="Confirmar Contraseña")
    
    # Campo para distinguir si es Profesor (Staff) o Alumno
    # Nota: Los Superusuarios (Banco) se crean con createsuperuser en la terminal.
    is_professor = forms.BooleanField(required=False, label="Marcar si es un Profesor (Usuario Staff)")

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']
        labels = {
            'username': 'Nombre de Usuario',
            'first_name': 'Nombre',
            'last_name': 'Apellido',
            'email': 'Correo Electrónico (Opcional)',
        }

    # Validación para asegurar que las contraseñas coinciden
    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        password_confirm = cleaned_data.get("password_confirm")

        if password and password != password_confirm:
            self.add_error('password_confirm', "Las contraseñas no coinciden.")
        return cleaned_data

# Formulario para crear un Producto
class ProductoCreationForm(forms.ModelForm):
    class Meta:
        model = Producto
        # Usamos 'descripcion' que es un campo nuevo en models.py
        fields = ['nombre', 'descripcion', 'precio_tokens', 'is_active']
        labels = {
            'nombre': 'Nombre del Producto',
            'descripcion': 'Descripción (opcional)',
            'precio_tokens': 'Precio en TecTokens',
            'is_active': 'Activo en la Tienda',
        }

# Formulario para crear un Grupo (Se usan los ManyToManyFields para seleccionar usuarios)
class GrupoCreationForm(forms.ModelForm):
    class Meta:
        model = Grupo
        # Los campos 'profesores' y 'alumnos' se filtran automáticamente en models.py
        fields = ['nombre', 'profesores', 'alumnos']
        labels = {
            'nombre': 'Nombre del Grupo',
            'profesores': 'Profesores del Grupo',
            'alumnos': 'Alumnos del Grupo',
        }