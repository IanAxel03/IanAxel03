from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import Perfil, Grupo, Producto, Compra # <-- Añadimos los nuevos

# --- Configuración de User/Perfil ---
class PerfilInline(admin.StackedInline):
    model = Perfil
    can_delete = False
    verbose_name_plural = 'Perfiles'

class UserAdmin(BaseUserAdmin):
    inlines = (PerfilInline,)
    # Mostramos si es staff en la lista de usuarios
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'is_superuser')
    list_filter = ('is_staff', 'is_superuser', 'groups')

admin.site.unregister(User)
admin.site.register(User, UserAdmin)

# --- Configuración de Grupo ---
@admin.register(Grupo)
class GrupoAdmin(admin.ModelAdmin):
    list_display = ('nombre',)
    filter_horizontal = ('profesores', 'alumnos',)

# --- Configuración de Producto (¡NUEVO!) ---
@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'precio_tokens', 'is_active') # Columnas en la lista
    list_filter = ('is_active',) # Filtro lateral
    search_fields = ('nombre',) # Buscador

# --- Configuración de Compra (¡NUEVO!) ---
@admin.register(Compra)
class CompraAdmin(admin.ModelAdmin):
    list_display = ('alumno', 'producto', 'fecha', 'tx_hash')
    list_filter = ('producto', 'fecha',)
    search_fields = ('alumno__username', 'tx_hash',)
    # Hacemos que los campos sean de solo lectura
    readonly_fields = ('alumno', 'producto', 'fecha', 'tx_hash')
    # No se pueden añadir Compras desde el Admin
    def has_add_permission(self, request):
        return False