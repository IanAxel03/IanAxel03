from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# --- MODELO 1: Perfil (El Enlace) ---
class Perfil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="perfil")
    wallet_address = models.CharField(
        max_length=42, 
        unique=True, 
        null=True, 
        blank=True,
        verbose_name="Dirección de Wallet"
    )

    def __str__(self):
        tipo = "Banco" if self.user.is_superuser else ("Profesor" if self.user.is_staff else "Alumno")
        return f"Perfil de {self.user.username} ({tipo}) - Wallet: {self.wallet_address or 'No asignada'}"

# --- MODELO 2: Grupos ---
class Grupo(models.Model):
    nombre = models.CharField(max_length=100, unique=True, verbose_name="Nombre del Grupo")
    profesores = models.ManyToManyField(User, 
                                        related_name="grupos_gestionados",
                                        limit_choices_to={'is_staff': True, 'is_superuser': False})
    alumnos = models.ManyToManyField(User, 
                                     related_name="grupos_pertenecientes",
                                     limit_choices_to={'is_staff': False})

    def __str__(self):
        return self.nombre

# --- MODELO 3: Producto (¡NUEVO!) ---
# Los productos que el "Banco" crea en la tienda.
class Producto(models.Model):
    nombre = models.CharField(max_length=100, verbose_name="Nombre del Producto")
    descripcion = models.TextField(blank=True, verbose_name="Descripción (opcional)")
    precio_tokens = models.PositiveIntegerField(default=10, verbose_name="Precio (en TecTokens)")
    is_active = models.BooleanField(default=True, verbose_name="¿Está activo en la tienda?")
    
    class Meta:
        verbose_name = "Producto"
        verbose_name_plural = "Productos"

    def __str__(self):
        return f"{self.nombre} ({self.precio_tokens} TEC)"

# --- MODELO 4: Compra (¡NUEVO!) ---
# Un registro de qué alumno compró qué producto.
class Compra(models.Model):
    alumno = models.ForeignKey(User, on_delete=models.PROTECT, related_name="compras", limit_choices_to={'is_staff': False})
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT, related_name="ventas")
    fecha = models.DateTimeField(auto_now_add=True)
    tx_hash = models.CharField(max_length=66, unique=True, help_text="Hash de la transacción en la blockchain")

    class Meta:
        verbose_name = "Compra"
        verbose_name_plural = "Compras"
        ordering = ['-fecha'] # Mostrar las más nuevas primero

    def __str__(self):
        return f"{self.alumno.username} compró {self.producto.nombre} el {self.fecha.strftime('%d/%m/%Y')}"

# --- SEÑAL (SIGNAL) ---
# Crea un Perfil (vacío) automáticamente para CADA nuevo User.
@receiver(post_save, sender=User)
def crear_perfil_usuario(sender, instance, created, **kwargs):
    if created:
        Perfil.objects.create(user=instance)