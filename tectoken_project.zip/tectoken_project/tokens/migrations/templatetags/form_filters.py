from django import template

register = template.Library()

@register.filter(name='add_attrs')
def add_attrs(field, attrs_string):
    """
    Añade atributos a un campo de formulario en la plantilla.
    
    Uso: {{ field|add_attrs:"class:input-style" }}
    Uso: {{ field|add_attrs:"class:input-style,style:height: 150px" }}
    """
    attrs = {}
    
    # Divide el string por comas (para múltiples atributos)
    for attr in attrs_string.split(','):
        try:
            # Divide cada atributo por el primer ':'
            key, value = attr.split(':', 1)
            attrs[key.strip()] = value.strip()
        except ValueError:
            pass
            
    # as_widget() es válido aquí porque esto es código Python
    return field.as_widget(attrs=attrs)