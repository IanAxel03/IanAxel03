from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.db import transaction

# Importamos los modelos y formularios necesarios
from .models import Perfil, Grupo, Producto, Compra
from .forms import UserCreationForm, ProductoCreationForm, GrupoCreationForm

# --- VISTAS AUXILIARES ---

# Predicado para verificar si el usuario es un Superuser (el Banco)
def is_bank(user):
    return user.is_superuser

# Predicado para verificar si el usuario es un Profesor (Staff)
def is_professor(user):
    return user.is_staff and not user.is_superuser

# --- RUTAS DE LA APLICACIÓN WEB ---

@login_required
def home(request):
    """
    Ruta de inicio. Redirige según el rol del usuario.
    """
    if request.user.is_superuser:
        return redirect('dashboard_banco')
    elif request.user.is_staff:
        return redirect('dashboard_profesor')
    else:
        return redirect('dashboard_alumno')

@login_required
@user_passes_test(lambda u: not u.is_staff, login_url='/accounts/login/')
def dashboard_alumno(request):
    """
    Panel del Alumno (Ver saldo y historial, ir a tienda).
    """
    # Aquí, por ahora, le pasamos la wallet del banco al alumno para que sepa dónde enviar tokens en la tienda.
    banco_perfil = Perfil.objects.filter(user__is_superuser=True).first()
    
    context = {
        'perfil': request.user.perfil,
        'banco_wallet': banco_perfil.wallet_address if banco_perfil and banco_perfil.wallet_address else '',
        'productos': Producto.objects.filter(is_active=True).order_by('precio_tokens'),
    }
    return render(request, 'tokens/dashboard_alumno.html', context)


@login_required
@user_passes_test(is_professor, login_url='/accounts/login/')
def dashboard_profesor(request):
    """
    Panel del Profesor (Depositar tokens a alumnos, ver su saldo).
    """
    # Solo muestra grupos que el profesor gestiona
    grupos_del_profesor = Grupo.objects.filter(profesores=request.user)
    
    # Obtener alumnos en esos grupos (para el filtro del JS)
    alumnos_en_grupos = User.objects.filter(
        grupos_pertenecientes__in=grupos_del_profesor
    ).distinct().order_by('username')

    context = {
        'perfil': request.user.perfil,
        'grupos': grupos_del_profesor,
        'alumnos': alumnos_en_grupos,
    }
    return render(request, 'tokens/dashboard_profesor.html', context)


@login_required
@user_passes_test(lambda u: not u.is_staff, login_url='/accounts/login/')
def tienda(request):
    """
    Página de la Tienda de Recompensas.
    """
    # Solo mostrar productos activos
    productos_activos = Producto.objects.filter(is_active=True).order_by('precio_tokens')

    # Aquí, por ahora, le pasamos la wallet del banco al alumno para que sepa dónde enviar tokens en la compra.
    banco_perfil = Perfil.objects.filter(user__is_superuser=True).first()

    context = {
        'perfil': request.user.perfil,
        'productos': productos_activos,
        'banco_wallet': banco_perfil.wallet_address if banco_perfil and banco_perfil.wallet_address else '',
    }
    return render(request, 'tokens/tienda.html', context)


@login_required
@user_passes_test(is_bank, login_url='/accounts/login/')
def dashboard_banco(request):
    """
    Panel del Banco (Superuser) - Administración y Recarga.
    """
    # Obtenemos los formularios para el panel administrativo
    user_form = UserCreationForm()
    producto_form = ProductoCreationForm()
    grupo_form = GrupoCreationForm()

    # Filtramos solo a los usuarios marcados como staff (profesores)
    profesores_activos = User.objects.filter(is_staff=True, is_superuser=False).order_by('username')
    
    # Obtenemos la wallet del banco (que es la del superuser)
    banco_wallet = request.user.perfil.wallet_address if request.user.perfil else ''

    context = {
        'perfil': request.user.perfil,
        'profesores': profesores_activos,
        'banco_wallet': banco_wallet,
        # Formularios para la columna de gestión
        'user_form': user_form,
        'producto_form': producto_form,
        'grupo_form': grupo_form,
    }
    return render(request, 'tokens/banco_dashboard.html', context)


# --- RUTAS API PARA LA GESTIÓN DEL BANCO (SIN METAMASK) ---

@user_passes_test(is_bank)
@transaction.atomic
def crear_usuario(request):
    """
    API para crear un nuevo Profesor o Alumno desde el panel del Banco.
    """
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            password = form.cleaned_data['password']
            is_professor = form.cleaned_data['is_professor']
            
            # 1. Configurar tipo de usuario y contraseña
            user.set_password(password)
            user.is_staff = is_professor
            user.is_superuser = False
            user.save()
            
            # El signal crea el Perfil automáticamente
            
            return JsonResponse({
                'success': True,
                'message': f"Usuario '{user.username}' creado con éxito.",
                'user_id': user.id
            })
        else:
            # Retorna errores del formulario
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    
    return JsonResponse({'success': False, 'message': 'Método no permitido.'}, status=405)


@user_passes_test(is_bank)
@transaction.atomic
def crear_producto(request):
    """
    API para crear un nuevo Producto desde el panel del Banco.
    """
    if request.method == 'POST':
        form = ProductoCreationForm(request.POST)
        if form.is_valid():
            producto = form.save()
            
            return JsonResponse({
                'success': True,
                'message': f"Producto '{producto.nombre}' creado con éxito.",
                'producto_id': producto.id
            })
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    
    return JsonResponse({'success': False, 'message': 'Método no permitido.'}, status=405)

@user_passes_test(is_bank)
@transaction.atomic
def crear_grupo(request):
    """
    API para crear un nuevo Grupo desde el panel del Banco.
    """
    if request.method == 'POST':
        form = GrupoCreationForm(request.POST)
        if form.is_valid():
            grupo = form.save()
            
            return JsonResponse({
                'success': True,
                'message': f"Grupo '{grupo.nombre}' creado con éxito.",
                'grupo_id': grupo.id
            })
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    
    return JsonResponse({'success': False, 'message': 'Método no permitido.'}, status=405)


# --- RUTAS API PARA CONEXIÓN DE WALLET (A FUTURO) ---

@login_required
def link_wallet(request):
    """
    API para vincular la dirección de wallet al perfil del usuario actual (Profesor o Alumno).
    Esta función es llamada por JavaScript.
    """
    if request.method == 'POST':
        try:
            import json
            data = json.loads(request.body)
            wallet_address = data.get('wallet_address')

            if not wallet_address:
                return JsonResponse({'success': False, 'error': 'Dirección de wallet no proporcionada.'}, status=400)

            # Buscamos o creamos el perfil y le asignamos la wallet
            perfil, created = Perfil.objects.get_or_create(user=request.user)
            perfil.wallet_address = wallet_address
            perfil.save()
            
            return JsonResponse({'success': True, 'message': 'Wallet vinculada exitosamente.'})

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)
    
    return JsonResponse({'success': False, 'error': 'Método no permitido.'}, status=405)


@login_required
def comprar_producto(request):
    """
    API para registrar la compra de un alumno DESPUÉS de que la transacción en la blockchain fue exitosa.
    """
    if request.method == 'POST' and not request.user.is_staff and not request.user.is_superuser:
        try:
            import json
            data = json.loads(request.body)
            producto_id = data.get('producto_id')
            tx_hash = data.get('tx_hash')
            
            producto = Producto.objects.get(id=producto_id)
            
            # Registramos la compra
            Compra.objects.create(
                alumno=request.user,
                producto=producto,
                tx_hash=tx_hash
            )
            
            return JsonResponse({'success': True, 'message': 'Compra registrada con éxito en la DB.'})
            
        except Producto.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'El producto no existe.'}, status=404)
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)

    return JsonResponse({'success': False, 'error': 'Acceso denegado o método no permitido.'}, status=405)