from django.urls import path
from . import views

urlpatterns = [
    # --- RUTAS WEB (PANELS) ---
    # La página principal '/'
    path('', views.home, name='home'), 
    # Dashboard del Alumno
    path('alumno/', views.dashboard_alumno, name='dashboard_alumno'),
    # Dashboard del Profesor
    path('profesor/', views.dashboard_profesor, name='dashboard_profesor'),
    # Página de la Tienda
    path('tienda/', views.tienda, name='tienda'),
    # Dashboard del Banco (Superuser)
    path('banco/', views.dashboard_banco, name='dashboard_banco'),
    
    # --- RUTAS API PARA GESTIÓN DEL BANCO (Nuevas) ---
    # Estas API reciben los datos del formulario de la ventana del Banco.
    path('api/crear_usuario/', views.crear_usuario, name='crear_usuario'),
    path('api/crear_producto/', views.crear_producto, name='crear_producto'),
    path('api/crear_grupo/', views.crear_grupo, name='crear_grupo'),

    # --- RUTAS API PARA LA BLOCKCHAIN (A futuro) ---
    # Estas APIs se usarán cuando se reactive la conexión con MetaMask/Ethers.
    path('api/link_wallet/', views.link_wallet, name='link_wallet'), 
    path('api/comprar_producto/', views.comprar_producto, name='comprar_producto'),
]